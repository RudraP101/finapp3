// This component has been replaced by ScrollableReader
// Keeping this file as a placeholder to avoid import errors
import React from 'react';

interface DailyStoriesProps {
  onBack: () => void;
  onStoryDetail: (story: any) => void;
}

export function DailyStories({ onBack, onStoryDetail }: DailyStoriesProps) {
  // Component deprecated - functionality moved to ScrollableReader
  return null;
}