import React, { useState } from 'react';
import { Search, TrendingUp, DollarSign, GraduationCap, Briefcase, Home, Zap, Filter } from 'lucide-react';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card } from './ui/card';
import exampleImage from 'figma:asset/edbc8b788a7db39e95a230af3b6b643e6ec4a3f2.png';

interface ExploreScreenProps {
  onStoryDetail: (story: any) => void;
}

export function ExploreScreen({ onStoryDetail }: ExploreScreenProps) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { name: 'All', icon: <Zap className="w-4 h-4" />, color: 'bg-teal-500 text-white', count: 24 },
    { name: 'Economy', icon: <TrendingUp className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 8 },
    { name: 'Investing', icon: <DollarSign className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 6 },
    { name: 'Student Finance', icon: <GraduationCap className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 4 },
    { name: 'Jobs', icon: <Briefcase className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 3 },
    { name: 'Housing', icon: <Home className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 3 },
  ];

  const trendingTopics = [
    'Interest Rate Cuts', 'Crypto Rally', 'Student Loans', 'Job Market', 'Housing Crisis', 'Inflation'
  ];

  const stories = [
    {
      id: '1',
      headline: 'Fed Cuts Interest Rates Again',
      summary: 'Another 0.25% cut signals continued support for economic growth',
      category: 'Economy',
      readTime: '2 min read',
      timeAgo: '2h ago',
      trending: true,
      badge: 'Trending'
    },
    {
      id: '2',
      headline: 'Student Loan Forgiveness Update',
      summary: '$7.4B in loans forgiven for public service workers',
      category: 'Student Finance',
      readTime: '3 min read',
      timeAgo: '4h ago',
      trending: false,
      badge: null
    },
    {
      id: '3',
      headline: 'Tech Job Market Rebounds',
      summary: 'Major companies resume hiring after layoff wave',
      category: 'Jobs',
      readTime: '2 min read',
      timeAgo: '6h ago',
      trending: true,
      badge: 'Trending'
    },
    {
      id: '4',
      headline: 'Housing Prices Cool in Major Cities',
      summary: 'First monthly decline in 18 months signals market shift',
      category: 'Housing',
      readTime: '3 min read',
      timeAgo: '8h ago',
      trending: false,
      badge: null
    },
    {
      id: '5',
      headline: 'Crypto Market Rallies 15%',
      summary: 'Bitcoin hits $45K as institutional investors buy the dip',
      category: 'Investing',
      readTime: '2 min read',
      timeAgo: '10h ago',
      trending: true,
      badge: 'Trending'
    }
  ];

  const filteredStories = activeCategory === 'All' 
    ? stories 
    : stories.filter(story => story.category === activeCategory);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white pt-12 pb-6 px-4">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Explore</h1>
        
        {/* Search bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search financial news..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-12 rounded-xl border-gray-200 focus:border-teal-500 focus:ring-teal-500 bg-gray-50"
          />
          <Button 
            size="sm" 
            variant="ghost" 
            className="absolute right-2 top-1/2 transform -translate-y-1/2 rounded-lg p-1"
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Category filters */}
      <div className="px-4 mb-6">
        <div className="flex space-x-2 overflow-x-auto scrollbar-hide">
          {categories.map((category) => (
            <Button
              key={category.name}
              variant={activeCategory === category.name ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(category.name)}
              className={`flex items-center space-x-2 rounded-full px-4 py-2 whitespace-nowrap border-0 ${
                activeCategory === category.name
                  ? category.color
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category.icon}
              <span>{category.name}</span>
              <span className="text-xs opacity-75">{category.count}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Trending topics */}
      <div className="px-4 mb-6">
        <h2 className="font-semibold text-gray-900 mb-3">Trending Now</h2>
        <div className="flex flex-wrap gap-2">
          {trendingTopics.map((topic) => (
            <Badge
              key={topic}
              variant="outline"
              className="rounded-full px-3 py-1 border-orange-200 text-orange-800 bg-orange-50 cursor-pointer hover:bg-orange-100 transition-colors text-sm"
            >
              🔥 {topic}
            </Badge>
          ))}
        </div>
      </div>

      {/* Stories list */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-gray-900">Latest Stories</h2>
          <span className="text-sm text-gray-500">{filteredStories.length} stories</span>
        </div>

        <div className="space-y-3">
          {filteredStories.map((story) => (
            <Card
              key={story.id}
              className="bg-white rounded-xl border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onStoryDetail(story)}
            >
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                      {story.category}
                    </Badge>
                    {story.badge && (
                      <Badge variant="secondary" className="bg-orange-100 text-orange-800 text-xs">
                        🔥 {story.badge}
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs text-gray-500">{story.timeAgo}</span>
                </div>

                <h3 className="font-semibold text-gray-900 mb-2 text-base">
                  {story.headline}
                </h3>

                <p className="text-sm text-gray-600 mb-3 leading-relaxed">
                  {story.summary}
                </p>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">{story.readTime}</span>
                  <span className="text-teal-600 font-medium text-sm">Read →</span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Load more */}
      <div className="p-4 mt-6">
        <Button 
          variant="outline" 
          className="w-full rounded-xl py-3 border-gray-200 bg-white hover:bg-gray-50"
        >
          Load More Stories
        </Button>
      </div>
    </div>
  );
}