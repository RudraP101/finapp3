import React, { useState } from 'react';
import { Button } from './ui/button';
import { ChevronLeft, ChevronRight, TrendingUp, Zap, Target } from 'lucide-react';

interface OnboardingScreensProps {
  onComplete: () => void;
}

export function OnboardingScreens({ onComplete }: OnboardingScreensProps) {
  const [currentScreen, setCurrentScreen] = useState(0);

  const screens = [
    {
      icon: <Zap className="w-24 h-24 text-teal-500" />,
      title: "Quick Stories",
      subtitle: "Get 3-5 curated financial news stories daily",
      description: "Skip the boring stuff. We serve you bite-sized financial news that actually matters to your life.",
      bgColor: "bg-gradient-to-br from-teal-100 to-teal-200"
    },
    {
      icon: <Target className="w-24 h-24 text-purple-500" />,
      title: "Why It Matters",
      subtitle: "Understand the impact on your wallet",
      description: "Every story comes with a 'Why You Should Care' explanation that connects to your daily life.",
      bgColor: "bg-gradient-to-br from-purple-100 to-purple-200"
    },
    {
      icon: <TrendingUp className="w-24 h-24 text-lime-500" />,
      title: "Stay Informed Fast",
      subtitle: "Build streaks, earn badges, level up",
      description: "Make staying informed fun with daily streaks, achievements, and rewards for consistent reading.",
      bgColor: "bg-gradient-to-br from-lime-100 to-lime-200"
    }
  ];

  const nextScreen = () => {
    if (currentScreen < screens.length - 1) {
      setCurrentScreen(currentScreen + 1);
    } else {
      onComplete();
    }
  };

  const prevScreen = () => {
    if (currentScreen > 0) {
      setCurrentScreen(currentScreen - 1);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Progress indicator */}
      <div className="flex justify-center pt-12 pb-8">
        <div className="flex space-x-2">
          {screens.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                index === currentScreen ? 'bg-teal-500' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Main content */}
      <div className={`flex-1 ${screens[currentScreen].bgColor} relative overflow-hidden`}>
        <div className="flex flex-col items-center justify-center h-full p-8 text-center">
          <div className="mb-8 transform hover:scale-110 transition-transform duration-300">
            {screens[currentScreen].icon}
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            {screens[currentScreen].title}
          </h1>
          
          <h2 className="text-lg font-medium text-gray-700 mb-6">
            {screens[currentScreen].subtitle}
          </h2>
          
          <p className="text-base text-gray-600 leading-relaxed max-w-sm">
            {screens[currentScreen].description}
          </p>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-16 left-8 w-4 h-4 bg-white/40 rounded-full"></div>
        <div className="absolute top-32 right-12 w-6 h-6 bg-white/30 rounded-full"></div>
        <div className="absolute bottom-32 left-16 w-3 h-3 bg-white/50 rounded-full"></div>
      </div>

      {/* Navigation */}
      <div className="p-6 bg-white">
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={prevScreen}
            disabled={currentScreen === 0}
            className="flex items-center space-x-2"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Back</span>
          </Button>

          <Button
            onClick={nextScreen}
            className="bg-teal-500 hover:bg-teal-600 text-white px-8 py-3 rounded-xl font-medium text-base"
          >
            {currentScreen === screens.length - 1 ? "Let's Go! 🚀" : "Continue"}
            {currentScreen < screens.length - 1 && <ChevronRight className="w-4 h-4 ml-2" />}
          </Button>
        </div>

        {currentScreen === 0 && (
          <button
            onClick={onComplete}
            className="w-full text-center text-gray-500 text-sm"
          >
            Skip introduction
          </button>
        )}
      </div>
    </div>
  );
}