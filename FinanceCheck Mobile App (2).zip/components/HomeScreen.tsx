import React, { useState } from 'react';
import { Flame, ArrowRight, Clock, TrendingUp, Search, Filter, DollarSign, GraduationCap, Briefcase, Home, Zap, Shield, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Input } from './ui/input';

interface Story {
  id: string;
  headline: string;
  category: string;
  timeAgo: string;
  readTime: string;
  source?: string;
  summary: string;
  content?: string;
  vocabTerm?: {
    word: string;
    definition: string;
    example: string;
  };
}

interface HomeScreenProps {
  onDailyStories: () => void;
  onStoryDetail: (story: Story, stories?: Story[]) => void;
  onShowTopicStories: (topicName: string, stories: Story[], initialIndex: number) => void;
}

export function HomeScreen({ onDailyStories, onStoryDetail, onShowTopicStories }: HomeScreenProps) {
  const userName = 'Alex';
  const currentStreak = 7;
  const streakGoal = 14;
  const hasStreakFreeze = true;
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const getStreakMessage = () => {
    if (currentStreak >= 7) return "🔥 You're on fire!";
    if (currentStreak >= 3) return "💪 Keep it up!";
    return "🚀 Start your streak!";
  };

  // Generate last 7 days for streak calendar
  const generateStreakDays = () => {
    const days = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      const dayName = date.toLocaleDateString('en', { weekday: 'short' }).charAt(0);
      const hasRead = i < currentStreak;
      days.push({
        day: dayName,
        date: date.getDate(),
        hasRead,
        isToday: i === 0
      });
    }
    return days;
  };

  const streakDays = generateStreakDays();

  const categories = [
    { name: 'All', icon: <Zap className="w-4 h-4" />, color: 'bg-teal-500 text-white', count: 24 },
    { name: 'Economy', icon: <TrendingUp className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 8 },
    { name: 'Investing', icon: <DollarSign className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 6 },
    { name: 'Student Finance', icon: <GraduationCap className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 4 },
    { name: 'Jobs', icon: <Briefcase className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 3 },
    { name: 'Housing', icon: <Home className="w-4 h-4" />, color: 'bg-gray-100 text-gray-800', count: 3 },
  ];

  const trendingTopics = [
    'Interest Rate Cuts', 'Crypto Rally', 'Student Loans', 'Job Market', 'Housing Crisis', 'Inflation'
  ];

  // Topic story collections with complete story data
  const topicStoryCollections = [
    {
      topic: 'Economy',
      icon: '📊',
      color: 'bg-blue-500',
      stories: [
        {
          id: 'econ-1',
          headline: 'Fed Cuts Interest Rates Again',
          category: 'Economy',
          timeAgo: '2h ago',
          readTime: '3 min',
          source: 'Reuters',
          summary: 'Another 0.25% cut signals continued support for economic growth amid rising inflation concerns.',
          vocabTerm: {
            word: 'Federal Funds Rate',
            definition: 'The interest rate banks charge each other for overnight loans, set by the Federal Reserve.',
            example: 'When the Fed lowers the federal funds rate, it becomes cheaper for banks to borrow money, which they pass on to consumers through lower loan rates.'
          }
        },
        {
          id: 'econ-2',
          headline: 'GDP Growth Accelerates to 3.2%',
          category: 'Economy',
          timeAgo: '4h ago',
          readTime: '4 min',
          source: 'Bureau of Economic Analysis',
          summary: 'Stronger than expected quarterly growth driven by consumer spending and business investment.',
          vocabTerm: {
            word: 'Gross Domestic Product (GDP)',
            definition: 'The total value of all goods and services produced in a country during a specific period.',
            example: 'A GDP growth rate of 3.2% means the economy expanded by 3.2% compared to the previous quarter.'
          }
        },
        {
          id: 'econ-3',
          headline: 'Inflation Cools to 3.1%',
          category: 'Economy',
          timeAgo: '6h ago',
          readTime: '2 min',
          source: 'Bureau of Labor Statistics',
          summary: 'Monthly inflation rate shows signs of cooling as Federal Reserve policies take effect.',
          vocabTerm: {
            word: 'Consumer Price Index (CPI)',
            definition: 'A measure of the average change in prices paid by consumers for goods and services.',
            example: 'A CPI increase of 3.1% means prices for everyday items rose by 3.1% compared to last year.'
          }
        }
      ]
    },
    {
      topic: 'Investing',
      icon: '💰',
      color: 'bg-green-500',
      stories: [
        {
          id: 'inv-1',
          headline: 'Crypto Rally Continues as Bitcoin Hits $45K',
          category: 'Investing',
          timeAgo: '1h ago',
          readTime: '3 min',
          source: 'CoinDesk',
          summary: 'Major cryptocurrency surge driven by institutional investments and positive regulatory news.',
          vocabTerm: {
            word: 'Market Capitalization',
            definition: 'The total value of all coins or shares in circulation for a particular cryptocurrency or stock.',
            example: 'Bitcoin\'s market cap exceeded $800 billion as prices reached $45,000 per coin.'
          }
        },
        {
          id: 'inv-2',
          headline: 'Tech Stocks Surge 5% on AI News',
          category: 'Investing',
          timeAgo: '3h ago',
          readTime: '4 min',
          source: 'CNBC',
          summary: 'Major tech companies see significant gains following breakthrough AI announcements.',
          vocabTerm: {
            word: 'Price-to-Earnings Ratio (P/E)',
            definition: 'A valuation metric comparing a company\'s stock price to its earnings per share.',
            example: 'Tech stocks with P/E ratios above 30 are considered expensive, but investors pay premiums for growth potential.'
          }
        },
        {
          id: 'inv-3',
          headline: 'Bond Market Shows Signs of Recovery',
          category: 'Investing',
          timeAgo: '5h ago',
          readTime: '3 min',
          source: 'MarketWatch',
          summary: 'Treasury yields stabilize as investors show renewed confidence in fixed-income securities.',
          vocabTerm: {
            word: 'Bond Yield',
            definition: 'The annual return an investor receives from a bond, expressed as a percentage.',
            example: 'A 10-year Treasury bond with a 4.5% yield pays $45 annually for every $1,000 invested.'
          }
        }
      ]
    },
    {
      topic: 'Jobs & Career',
      icon: '💼',
      color: 'bg-orange-500',
      stories: [
        {
          id: 'jobs-1',
          headline: 'Job Market Stays Hot with 200K New Jobs',
          category: 'Jobs',
          timeAgo: '3h ago',
          readTime: '3 min',
          source: 'Bureau of Labor Statistics',
          summary: 'Employment growth continues strong despite economic uncertainties and rate hikes.',
          vocabTerm: {
            word: 'Labor Force Participation Rate',
            definition: 'The percentage of working-age people who are either employed or actively looking for work.',
            example: 'A participation rate of 63.4% means about 63 out of every 100 working-age adults are in the labor force.'
          }
        },
        {
          id: 'jobs-2',
          headline: 'Remote Work Trends Reshape Office Space',
          category: 'Jobs',
          timeAgo: '5h ago',
          readTime: '4 min',
          source: 'Harvard Business Review',
          summary: 'Companies adapt to hybrid work models, changing commercial real estate demand.',
          vocabTerm: {
            word: 'Hybrid Work Model',
            definition: 'A flexible work arrangement combining remote work with in-office presence.',
            example: 'Many companies now offer hybrid schedules where employees work from home 2-3 days per week.'
          }
        },
        {
          id: 'jobs-3',
          headline: 'Tech Hiring Rebounds After Layoff Wave',
          category: 'Jobs',
          timeAgo: '1d ago',
          readTime: '2 min',
          source: 'TechCrunch',
          summary: 'Major technology companies resume aggressive hiring following period of workforce reductions.',
          vocabTerm: {
            word: 'Skills Gap',
            definition: 'The difference between the skills employers need and the skills available in the workforce.',
            example: 'The tech industry faces a skills gap in AI and cybersecurity, driving up salaries for qualified professionals.'
          }
        }
      ]
    },
    {
      topic: 'Housing',
      icon: '🏠',
      color: 'bg-pink-500',
      stories: [
        {
          id: 'house-1',
          headline: 'Home Prices Cool Down in Major Cities',
          category: 'Housing',
          timeAgo: '4h ago',
          readTime: '3 min',
          source: 'National Association of Realtors',
          summary: 'First monthly decline in 18 months signals potential market correction ahead.',
          vocabTerm: {
            word: 'Housing Inventory',
            definition: 'The number of homes available for sale in a given market at a specific time.',
            example: 'Higher housing inventory typically leads to lower prices as buyers have more options to choose from.'
          }
        },
        {
          id: 'house-2',
          headline: 'Mortgage Rates Hit 7.5% High',
          category: 'Housing',
          timeAgo: '6h ago',
          readTime: '2 min',
          source: 'Freddie Mac',
          summary: 'Rising interest rates continue to impact home affordability across the country.',
          vocabTerm: {
            word: 'Debt-to-Income Ratio',
            definition: 'The percentage of monthly income that goes toward paying debts, including mortgage payments.',
            example: 'Lenders typically require a debt-to-income ratio below 36% for mortgage approval.'
          }
        },
        {
          id: 'house-3',
          headline: 'First-Time Buyer Programs Expand',
          category: 'Housing',
          timeAgo: '1d ago',
          readTime: '4 min',
          source: 'HUD',
          summary: 'New government initiatives aim to help young adults enter the housing market.',
          vocabTerm: {
            word: 'Down Payment Assistance',
            definition: 'Financial help provided to homebuyers to cover the initial payment required for a home purchase.',
            example: 'Many first-time buyer programs offer down payment assistance of 3-5% of the home\'s purchase price.'
          }
        }
      ]
    },
    {
      topic: 'Student Finance',
      icon: '🎓',
      color: 'bg-purple-500',
      stories: [
        {
          id: 'student-1',
          headline: 'Student Loan Forgiveness: $7.4B Approved',
          category: 'Student Finance',
          timeAgo: '2h ago',
          readTime: '3 min',
          source: 'Department of Education',
          summary: 'Latest round of public service loan forgiveness benefits 160,000 borrowers.',
          vocabTerm: {
            word: 'Public Service Loan Forgiveness (PSLF)',
            definition: 'A federal program that forgives student loans for qualifying public service employees after 10 years.',
            example: 'Teachers, nurses, and government workers can qualify for PSLF after making 120 qualifying monthly payments.'
          }
        },
        {
          id: 'student-2',
          headline: 'FAFSA Changes Take Effect in 2024',
          category: 'Student Finance',
          timeAgo: '1d ago',
          readTime: '4 min',
          source: 'Federal Student Aid',
          summary: 'Simplified application process aims to increase college affordability and access.',
          vocabTerm: {
            word: 'Expected Family Contribution (EFC)',
            definition: 'The amount a family is expected to pay toward college costs, calculated from FAFSA information.',
            example: 'An EFC of $3,000 means your family is expected to contribute $3,000 toward college expenses each year.'
          }
        },
        {
          id: 'student-3',
          headline: 'College Costs Rise 4% This Year',
          category: 'Student Finance',
          timeAgo: '2d ago',
          readTime: '2 min',
          source: 'College Board',
          summary: 'Tuition increases outpace inflation, raising concerns about higher education accessibility.',
          vocabTerm: {
            word: 'Net Price',
            definition: 'The actual cost of college after subtracting grants, scholarships, and other financial aid.',
            example: 'A college with $50,000 tuition might have a net price of $25,000 after financial aid is applied.'
          }
        }
      ]
    }
  ];

  // Handle topic story click
  const handleTopicStoryClick = (story: Story, topicStories: Story[]) => {
    const storyIndex = topicStories.findIndex(s => s.id === story.id);
    onShowTopicStories(story.category, topicStories, storyIndex);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header with greeting */}
      <div className="bg-white pt-12 pb-4 px-4">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          {getGreeting()}, {userName}! 👋
        </h1>
        <p className="text-gray-600 mb-4">Stay informed, stay ahead</p>
      </div>

      {/* Category filters */}
      <div className="px-4 mb-6">
        <div className="flex space-x-2 overflow-x-auto scrollbar-hide">
          {categories.map((category) => (
            <Button
              key={category.name}
              variant={activeCategory === category.name ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(category.name)}
              className={`flex items-center space-x-2 rounded-full px-4 py-2 whitespace-nowrap border-0 ${
                activeCategory === category.name
                  ? category.color
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category.icon}
              <span>{category.name}</span>
              <span className="text-xs opacity-75">{category.count}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Duolingo-style Streak section */}
      <div className="px-4 mb-6">
        <Card className="bg-white border-0 shadow-sm overflow-hidden">
          <div className="p-6">
            {/* Main streak display */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                {/* Animated flame icon */}
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-t from-orange-500 via-red-500 to-yellow-400 rounded-full flex items-center justify-center shadow-lg">
                    <Flame className="w-8 h-8 text-white animate-pulse" />
                  </div>
                  {currentStreak >= 3 && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-bold">🔥</span>
                    </div>
                  )}
                </div>
                
                <div>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-3xl font-bold text-gray-900">{currentStreak}</span>
                    <span className="text-lg text-gray-600 font-medium">day streak</span>
                  </div>
                  <p className="text-sm text-orange-600 font-medium">{getStreakMessage()}</p>
                </div>
              </div>
              
              {/* Streak freeze indicator */}
              {hasStreakFreeze && (
                <div className="flex items-center space-x-1 bg-blue-50 px-3 py-1 rounded-full">
                  <Shield className="w-4 h-4 text-blue-500" />
                  <span className="text-xs text-blue-700 font-medium">Protected</span>
                </div>
              )}
            </div>

            {/* Streak calendar */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-700">This week</span>
                <span className="text-xs text-gray-500">{currentStreak}/{streakGoal} days to goal</span>
              </div>
              
              <div className="flex justify-between">
                {streakDays.map((day, index) => (
                  <div key={index} className="flex flex-col items-center space-y-2">
                    <span className="text-xs text-gray-500 font-medium">{day.day}</span>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 ${
                      day.hasRead 
                        ? 'bg-green-500 border-green-500 text-white' 
                        : day.isToday 
                          ? 'bg-orange-100 border-orange-300 text-orange-600'
                          : 'bg-gray-100 border-gray-200 text-gray-400'
                    }`}>
                      {day.hasRead ? '✓' : day.date}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Progress to goal */}
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Goal Progress</span>
                <span className="text-xs text-gray-500">{streakGoal - currentStreak} days to go</span>
              </div>
              <Progress 
                value={(currentStreak / streakGoal) * 100} 
                className="h-2 bg-gray-200"
              />
            </div>
          </div>
        </Card>
      </div>

      {/* Daily news coverage */}
      <div className="px-4 mb-6">
        <Card 
          className="bg-white border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow mobile-touch"
          onClick={onDailyStories}
        >
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-1">
                  Here is your daily news coverage
                </h2>
                <p className="text-sm text-gray-600 mb-3">
                  8 curated stories ready for you
                </p>
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary" className="bg-teal-100 text-teal-800">
                    Daily Brief
                  </Badge>
                  <div className="flex items-center space-x-1 text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span className="text-xs">15 min read</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center mb-2">
                  <ArrowRight className="w-6 h-6 text-teal-600" />
                </div>
                <span className="text-xs text-gray-500">Tap to read</span>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Search bar moved here - below Daily News Coverage */}
      <div className="px-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search financial news..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-12 rounded-xl border-gray-200 focus:border-teal-500 focus:ring-teal-500 bg-gray-50"
          />
          <Button 
            size="sm" 
            variant="ghost" 
            className="absolute right-2 top-1/2 transform -translate-y-1/2 rounded-lg p-1"
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Trending topics */}
      <div className="px-4 mb-6">
        <h2 className="font-semibold text-gray-900 mb-3">Trending Now</h2>
        <div className="flex flex-wrap gap-2">
          {trendingTopics.map((topic) => (
            <Badge
              key={topic}
              variant="outline"
              className="rounded-full px-3 py-1 border-orange-200 text-orange-800 bg-orange-50 cursor-pointer hover:bg-orange-100 transition-colors text-sm mobile-touch"
            >
              🔥 {topic}
            </Badge>
          ))}
        </div>
      </div>

      {/* Horizontal Topic Story Collections */}
      <div className="mb-8">
        <div className="px-4 mb-4">
          <h2 className="font-semibold text-gray-900">Stories by Topic</h2>
        </div>

        <div className="space-y-6">
          {topicStoryCollections.map((topicGroup) => (
            <div key={topicGroup.topic}>
              {/* Topic Header */}
              <div className="px-4 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${topicGroup.color} rounded-xl flex items-center justify-center shadow-sm`}>
                      <span className="text-lg">{topicGroup.icon}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{topicGroup.topic}</h3>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 text-xs">
                          {topicGroup.stories.length} stories
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-teal-600 hover:text-teal-700"
                    onClick={() => onShowTopicStories(topicGroup.topic, topicGroup.stories, 0)}
                  >
                    View all
                  </Button>
                </div>
              </div>

              {/* Horizontal scrolling story cards */}
              <div className="pl-4">
                <div className="flex space-x-4 overflow-x-auto scrollbar-hide pb-2">
                  {topicGroup.stories.map((story, index) => (
                    <Card
                      key={story.id}
                      className="flex-shrink-0 w-80 bg-white rounded-xl border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer mobile-touch"
                      onClick={() => handleTopicStoryClick(story, topicGroup.stories)}
                    >
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center">
                              <span className="text-xs font-bold text-gray-600">#{index + 1}</span>
                            </div>
                          </div>
                          <span className="text-xs text-gray-500">{story.timeAgo}</span>
                        </div>

                        <h4 className="font-semibold text-gray-900 mb-3 text-base leading-snug line-clamp-2">
                          {story.headline}
                        </h4>

                        <p className="text-sm text-gray-600 mb-4 leading-relaxed line-clamp-2">
                          {story.summary}
                        </p>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2 text-xs text-gray-500">
                            <span>{story.readTime}</span>
                            {story.source && (
                              <>
                                <span>•</span>
                                <span>{story.source}</span>
                              </>
                            )}
                          </div>
                          <span className="text-teal-600 font-medium text-sm">Read →</span>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}