// This component has been replaced by ScrollableReader
// Keeping this file as a placeholder to avoid import errors
import React from 'react';

interface StoryDetailProps {
  story: any;
  onBack: () => void;
}

export function StoryDetail({ story, onBack }: StoryDetailProps) {
  // Component deprecated - functionality moved to ScrollableReader
  return null;
}