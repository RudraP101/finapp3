import React from 'react';
import { motion } from 'motion/react';
import { 
  Flame, 
  Trophy, 
  Target, 
  BookOpen, 
  Settings, 
  Bell, 
  Share, 
  Calendar,
  TrendingUp,
  Award,
  Star,
  Zap
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';

export function ProfileScreen() {
  const userStats = {
    name: 'Alex',
    level: 8,
    xp: 2840,
    nextLevelXp: 3200,
    streak: 12,
    totalStories: 156,
    categoriesRead: 5,
    weeklyGoal: 5,
    weeklyProgress: 4
  };

  const achievements = [
    { 
      id: 1, 
      name: 'News Ninja', 
      description: 'Read 100 stories', 
      icon: '🥷', 
      unlocked: true,
      rarity: 'rare'
    },
    { 
      id: 2, 
      name: 'Streak Master', 
      description: '10 day reading streak', 
      icon: '🔥', 
      unlocked: true,
      rarity: 'common'
    },
    { 
      id: 3, 
      name: 'Economy Expert', 
      description: 'Read 50 economy stories', 
      icon: '📈', 
      unlocked: true,
      rarity: 'uncommon'
    },
    { 
      id: 4, 
      name: 'Early Bird', 
      description: 'Read before 8 AM for 7 days', 
      icon: '🐦', 
      unlocked: false,
      rarity: 'legendary'
    },
    { 
      id: 5, 
      name: 'Completionist', 
      description: 'Read all daily stories for 30 days', 
      icon: '💯', 
      unlocked: false,
      rarity: 'epic'
    },
    { 
      id: 6, 
      name: 'Social Butterfly', 
      description: 'Share 25 stories', 
      icon: '🦋', 
      unlocked: true,
      rarity: 'uncommon'
    }
  ];

  const recentActivity = [
    { type: 'story', title: 'Fed Cuts Interest Rates Again', category: 'Economy', time: '2h ago' },
    { type: 'achievement', title: 'Earned "News Ninja" badge', time: '1d ago' },
    { type: 'streak', title: 'Reached 10 day streak', time: '2d ago' },
    { type: 'story', title: 'Student Loan Forgiveness Update', category: 'Student Finance', time: '2d ago' }
  ];

  const xpProgress = ((userStats.xp % (userStats.nextLevelXp - (userStats.level - 1) * 400)) / (userStats.nextLevelXp - (userStats.level - 1) * 400)) * 100;

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'uncommon': return 'bg-green-100 text-green-800 border-green-300';
      case 'rare': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'epic': return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'legendary': return 'bg-orange-100 text-orange-800 border-orange-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-teal-500 to-teal-600 text-white">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">Hey {userStats.name}! 👋</h1>
              <p className="text-teal-100">Keep up the great work!</p>
            </div>
            
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 rounded-full">
              <Settings className="w-5 h-5" />
            </Button>
          </div>

          {/* Level and XP */}
          <div className="bg-white/20 rounded-2xl p-4 mb-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Star className="w-5 h-5 text-yellow-300" />
                <span className="font-medium">Level {userStats.level}</span>
              </div>
              <span className="text-sm text-teal-100">{userStats.xp} XP</span>
            </div>
            <Progress value={xpProgress} className="h-2 bg-white/20" />
            <p className="text-xs text-teal-100 mt-2">
              {userStats.nextLevelXp - userStats.xp} XP to Level {userStats.level + 1}
            </p>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <Flame className="w-6 h-6 mx-auto mb-1 text-orange-300" />
              <div className="font-bold text-lg">{userStats.streak}</div>
              <div className="text-xs text-teal-100">Day Streak</div>
            </div>
            
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <BookOpen className="w-6 h-6 mx-auto mb-1" />
              <div className="font-bold text-lg">{userStats.totalStories}</div>
              <div className="text-xs text-teal-100">Stories Read</div>
            </div>
            
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <Target className="w-6 h-6 mx-auto mb-1" />
              <div className="font-bold text-lg">{userStats.weeklyProgress}/{userStats.weeklyGoal}</div>
              <div className="text-xs text-teal-100">Weekly Goal</div>
            </div>
          </div>
        </div>
      </div>

      {/* Achievements section */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-gray-900">Achievements</h2>
          <span className="text-sm text-gray-500">
            {achievements.filter(a => a.unlocked).length}/{achievements.length} unlocked
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          {achievements.map((achievement) => (
            <motion.div
              key={achievement.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Card 
                className={`p-4 border-2 ${achievement.unlocked 
                  ? getRarityColor(achievement.rarity) + ' shadow-md' 
                  : 'bg-gray-50 border-gray-200 opacity-60'
                }`}
              >
                <div className="text-2xl mb-2 text-center">
                  {achievement.unlocked ? achievement.icon : '🔒'}
                </div>
                <h3 className="font-medium text-sm text-center mb-1">
                  {achievement.name}
                </h3>
                <p className="text-xs text-center text-gray-600">
                  {achievement.description}
                </p>
                {achievement.unlocked && (
                  <Badge 
                    variant="outline" 
                    className={`mx-auto mt-2 text-xs ${getRarityColor(achievement.rarity)}`}
                  >
                    {achievement.rarity}
                  </Badge>
                )}
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Recent activity */}
        <div className="mb-6">
          <h2 className="font-bold text-gray-900 mb-4">Recent Activity</h2>
          <Card className="p-4 bg-white">
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    activity.type === 'story' ? 'bg-blue-100' :
                    activity.type === 'achievement' ? 'bg-yellow-100' :
                    'bg-orange-100'
                  }`}>
                    {activity.type === 'story' && <BookOpen className="w-4 h-4 text-blue-600" />}
                    {activity.type === 'achievement' && <Trophy className="w-4 h-4 text-yellow-600" />}
                    {activity.type === 'streak' && <Flame className="w-4 h-4 text-orange-600" />}
                  </div>
                  
                  <div className="flex-1">
                    <p className="font-medium text-sm text-gray-900">{activity.title}</p>
                    {'category' in activity && (
                      <p className="text-xs text-gray-500">{activity.category}</p>
                    )}
                  </div>
                  
                  <span className="text-xs text-gray-500">{activity.time}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-2 gap-4">
          <Button variant="outline" className="rounded-xl py-3 border-gray-300">
            <Bell className="w-4 h-4 mr-2" />
            Notifications
          </Button>
          
          <Button variant="outline" className="rounded-xl py-3 border-gray-300">
            <Share className="w-4 h-4 mr-2" />
            Share App
          </Button>
        </div>
      </div>
    </div>
  );
}