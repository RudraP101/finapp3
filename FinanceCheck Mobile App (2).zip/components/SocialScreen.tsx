import React, { useState } from 'react';
import { 
  Crown, 
  Trophy, 
  Medal, 
  Users, 
  MessageCircle, 
  ThumbsUp, 
  Share2, 
  Target,
  Flame,
  Star,
  TrendingUp,
  Award,
  Zap
} from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

export function SocialScreen() {
  const [activeTab, setActiveTab] = useState('leaderboard');

  const leaderboard = [
    { 
      rank: 1, 
      name: 'Emma Watson', 
      score: 2850, 
      avatar: '👩‍💼', 
      streak: 12, 
      badge: 'Market Master',
      change: '+5',
      predictions: 89,
      accuracy: 94
    },
    { 
      rank: 2, 
      name: 'Marcus Chen', 
      score: 2720, 
      avatar: '👨‍💻', 
      streak: 8, 
      badge: 'Crypto King',
      change: '+2',
      predictions: 76,
      accuracy: 91
    },
    { 
      rank: 3, 
      name: 'Sofia Rodriguez', 
      score: 2650, 
      avatar: '👩‍🎓', 
      streak: 15, 
      badge: 'News Ninja',
      change: '-1',
      predictions: 82,
      accuracy: 88
    },
    { 
      rank: 4, 
      name: 'Alex Johnson', 
      score: 2420, 
      avatar: '🫵', 
      streak: 7, 
      badge: 'Rising Star',
      change: '+3',
      predictions: 45,
      accuracy: 87,
      isUser: true
    },
    { 
      rank: 5, 
      name: 'David Kim', 
      score: 2380, 
      avatar: '👨‍🔬', 
      streak: 6, 
      badge: 'Tech Guru',
      change: '0',
      predictions: 52,
      accuracy: 85
    }
  ];

  const achievements = [
    { title: 'First Prediction', icon: '🎯', unlocked: true },
    { title: 'Week Warrior', icon: '⚡', unlocked: true },
    { title: 'Market Mover', icon: '📈', unlocked: true },
    { title: 'Social Star', icon: '⭐', unlocked: false },
    { title: 'Perfect Week', icon: '💯', unlocked: false },
    { title: 'Trend Setter', icon: '🔥', unlocked: false }
  ];

  const friendActivity = [
    {
      id: 1,
      user: 'Emma Watson',
      avatar: '👩‍💼',
      action: 'predicted Bitcoin will rise 5%',
      time: '2h ago',
      likes: 24,
      comments: 8
    },
    {
      id: 2,
      user: 'Marcus Chen',
      avatar: '👨‍💻',
      action: 'achieved a 10-day streak!',
      time: '4h ago',
      likes: 31,
      comments: 12
    },
    {
      id: 3,
      user: 'Sofia Rodriguez',
      avatar: '👩‍🎓',
      action: 'shared insight on housing market',
      time: '6h ago',
      likes: 18,
      comments: 5
    }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2: return <Medal className="w-6 h-6 text-gray-400" />;
      case 3: return <Award className="w-6 h-6 text-orange-500" />;
      default: return null;
    }
  };

  const getChangeColor = (change: string) => {
    if (change.startsWith('+')) return 'text-green-600';
    if (change.startsWith('-')) return 'text-red-600';
    return 'text-gray-500';
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 pt-12 pb-4">
        <div className="px-4">
          <h1 className="text-xl font-bold text-gray-900 mb-1">Social Hub</h1>
          <p className="text-sm text-gray-600">Connect, compete, and learn together</p>
        </div>
      </div>

      {/* Tab Navigation - Fixed text visibility */}
      <div className="bg-white px-4 py-2">
        <div className="flex space-x-1 bg-gray-100 rounded-xl p-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveTab('leaderboard')}
            className={`flex-1 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'leaderboard' 
                ? 'bg-white shadow-sm text-gray-900' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Trophy className="w-4 h-4 mr-2" />
            Leaderboard
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveTab('activity')}
            className={`flex-1 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'activity' 
                ? 'bg-white shadow-sm text-gray-900' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Users className="w-4 h-4 mr-2" />
            Activity
          </Button>
        </div>
      </div>

      <div className="p-4">
        {/* Leaderboard Tab */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-6">
            {/* Current User Stats */}
            <Card className="bg-gradient-to-r from-teal-500 to-blue-600 text-white border-0 shadow-lg">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <span className="text-xl">🫵</span>
                    </div>
                    <div>
                      <h3 className="font-semibold">Alex Johnson</h3>
                      <p className="text-sm text-white/80">Rank #4 • Rising Star</p>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">2,420</div>
                    <div className="text-xs text-white/80">Score</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="font-bold">7</div>
                    <div className="text-xs text-white/80">Streak</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">45</div>
                    <div className="text-xs text-white/80">Predictions</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">87%</div>
                    <div className="text-xs text-white/80">Accuracy</div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Achievements */}
            <Card className="bg-white border-0 shadow-sm">
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-4">Recent Achievements</h3>
                <div className="grid grid-cols-3 gap-3">
                  {achievements.map((achievement, index) => (
                    <div 
                      key={index}
                      className={`text-center p-3 rounded-xl border-2 ${
                        achievement.unlocked 
                          ? 'bg-yellow-50 border-yellow-200' 
                          : 'bg-gray-50 border-gray-200 opacity-60'
                      }`}
                    >
                      <div className="text-2xl mb-1">{achievement.icon}</div>
                      <div className="text-xs font-medium text-gray-700">{achievement.title}</div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            {/* Leaderboard - Removed random numbers */}
            <Card className="bg-white border-0 shadow-sm">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900">Global Leaderboard</h3>
                  <Badge variant="secondary" className="bg-teal-100 text-teal-800">
                    This Week
                  </Badge>
                </div>

                <div className="space-y-3">
                  {leaderboard.map((user) => (
                    <div 
                      key={user.rank}
                      className={`flex items-center justify-between p-4 rounded-xl transition-all ${
                        user.isUser 
                          ? 'bg-teal-50 border-2 border-teal-200 shadow-sm' 
                          : 'bg-gray-50 hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex items-center space-x-4">
                        {/* Only show rank icons for top 3, nothing for others */}
                        <div className="flex items-center justify-center w-8 h-8">
                          {getRankIcon(user.rank)}
                        </div>
                        
                        <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border-2 border-gray-100">
                          <span className="text-lg">{user.avatar}</span>
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <span className={`font-semibold ${user.isUser ? 'text-teal-900' : 'text-gray-900'}`}>
                              {user.name}
                            </span>
                            <Badge variant="outline" className="text-xs px-2 py-0">
                              {user.badge}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-4 text-xs text-gray-600 mt-1">
                            <span>🔥 {user.streak} streak</span>
                            <span>🎯 {user.predictions} predictions</span>
                            <span>✅ {user.accuracy}% accurate</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className={`font-bold ${user.isUser ? 'text-teal-900' : 'text-gray-900'}`}>
                          {user.score.toLocaleString()}
                        </div>
                        <div className={`text-xs ${getChangeColor(user.change)}`}>
                          {user.change !== '0' && (user.change.startsWith('+') || user.change.startsWith('-')) ? user.change : '—'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Activity Tab */}
        {activeTab === 'activity' && (
          <div className="space-y-4">
            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-3">
              <Card className="bg-white border-0 shadow-sm text-center p-4">
                <div className="text-2xl font-bold text-gray-900 mb-1">156</div>
                <div className="text-sm text-gray-600">Friends</div>
              </Card>
              <Card className="bg-white border-0 shadow-sm text-center p-4">
                <div className="text-2xl font-bold text-gray-900 mb-1">89</div>
                <div className="text-sm text-gray-600">Likes Given</div>
              </Card>
              <Card className="bg-white border-0 shadow-sm text-center p-4">
                <div className="text-2xl font-bold text-gray-900 mb-1">124</div>
                <div className="text-sm text-gray-600">Comments</div>
              </Card>
            </div>

            {/* Friend Activity Feed */}
            <Card className="bg-white border-0 shadow-sm">
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-4">Friend Activity</h3>
                
                <div className="space-y-4">
                  {friendActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-xl">
                      <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm">
                        <span className="text-sm">{activity.avatar}</span>
                      </div>
                      
                      <div className="flex-1">
                        <div className="text-sm">
                          <span className="font-medium text-gray-900">{activity.user}</span>
                          <span className="text-gray-600 ml-1">{activity.action}</span>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">{activity.time}</div>
                        
                        <div className="flex items-center space-x-4 mt-2">
                          <button className="flex items-center space-x-1 text-gray-500 hover:text-teal-600 mobile-touch">
                            <ThumbsUp className="w-4 h-4" />
                            <span className="text-xs">{activity.likes}</span>
                          </button>
                          <button className="flex items-center space-x-1 text-gray-500 hover:text-teal-600 mobile-touch">
                            <MessageCircle className="w-4 h-4" />
                            <span className="text-xs">{activity.comments}</span>
                          </button>
                          <button className="flex items-center space-x-1 text-gray-500 hover:text-teal-600 mobile-touch">
                            <Share2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            {/* Challenges */}
            <Card className="bg-white border-0 shadow-sm">
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-4">Weekly Challenges</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <Target className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">Make 10 Predictions</div>
                        <div className="text-sm text-gray-600">Progress: 7/10</div>
                      </div>
                    </div>
                    <Badge className="bg-purple-500">
                      30 XP
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gradient-to-r from-green-50 to-teal-50 rounded-xl border border-green-200">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <Flame className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">7-Day Reading Streak</div>
                        <div className="text-sm text-gray-600">Progress: 7/7 ✓</div>
                      </div>
                    </div>
                    <Badge className="bg-green-500">
                      Complete!
                    </Badge>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}