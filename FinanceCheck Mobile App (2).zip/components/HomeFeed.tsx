import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Share, Bookmark, ChevronUp, ChevronDown, Flame, Clock } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface Story {
  id: string;
  headline: string;
  keyPoints: string[];
  whyYouCare: string;
  category: string;
  readTime: string;
  color: string;
  isBookmarked: boolean;
}

interface HomeFeedProps {
  onStoryDetail: (story: Story) => void;
}

export function HomeFeed({ onStoryDetail }: HomeFeedProps) {
  const [currentStory, setCurrentStory] = useState(0);
  const [bookmarkedStories, setBookmarkedStories] = useState<Set<string>>(new Set());

  const stories: Story[] = [
    {
      id: '1',
      headline: 'Fed Cuts Interest Rates Again',
      keyPoints: [
        'Federal Reserve lowers rates by 0.25%',
        'Good news for borrowers, loans get cheaper'
      ],
      whyYouCare: 'Your credit card and student loan payments could get smaller',
      category: 'Economy',
      readTime: '2 min',
      color: 'from-blue-400 to-blue-600',
      isBookmarked: false
    },
    {
      id: '2',
      headline: 'Student Loan Forgiveness Update',
      keyPoints: [
        '$7.4B in loans forgiven for public service workers',
        'New streamlined application process launches'
      ],
      whyYouCare: 'You might qualify for loan forgiveness if you work in public service',
      category: 'Student Finance',
      readTime: '3 min',
      color: 'from-green-400 to-green-600',
      isBookmarked: false
    },
    {
      id: '3',
      headline: 'Crypto Market Rallies 15%',
      keyPoints: [
        'Bitcoin hits $45K, major altcoins surge',
        'Institutional investors buying the dip'
      ],
      whyYouCare: 'Your crypto investments (if any) are up, but volatility remains high',
      category: 'Investing',
      readTime: '2 min',
      color: 'from-purple-400 to-purple-600',
      isBookmarked: false
    },
    {
      id: '4',
      headline: 'Job Market Stays Hot',
      keyPoints: [
        'Unemployment drops to 3.4%',
        'Tech and healthcare leading job growth'
      ],
      whyYouCare: 'Great time to negotiate salary or switch jobs for better pay',
      category: 'Jobs',
      readTime: '2 min',
      color: 'from-orange-400 to-orange-600',
      isBookmarked: false
    }
  ];

  const swipeUp = () => {
    setCurrentStory((prev) => (prev + 1) % stories.length);
  };

  const swipeDown = () => {
    setCurrentStory((prev) => (prev - 1 + stories.length) % stories.length);
  };

  const toggleBookmark = (storyId: string) => {
    setBookmarkedStories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(storyId)) {
        newSet.delete(storyId);
      } else {
        newSet.add(storyId);
      }
      return newSet;
    });
  };

  const currentStoryData = stories[currentStory];
  const dailyProgress = ((currentStory + 1) / stories.length) * 100;

  return (
    <div className="min-h-screen bg-gray-900 relative overflow-hidden">
      {/* Header with streak */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-gradient-to-b from-black/50 to-transparent">
        <div className="flex justify-between items-center text-white">
          <div className="flex items-center space-x-2">
            <Flame className="w-5 h-5 text-orange-500" />
            <span className="font-medium">7 day streak</span>
          </div>
          <div className="text-right">
            <div className="text-sm opacity-80">Daily Progress</div>
            <div className="text-xs">{currentStory + 1}/{stories.length}</div>
          </div>
        </div>
        <Progress value={dailyProgress} className="mt-2 h-1" />
      </div>

      {/* Story cards */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStory}
          initial={{ y: '100%', opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: '-100%', opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className={`absolute inset-0 bg-gradient-to-br ${currentStoryData.color}`}
        >
          {/* Navigation arrows */}
          <div className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 flex flex-col space-y-4">
            <Button
              size="sm"
              variant="ghost"
              onClick={swipeUp}
              className="bg-white/20 hover:bg-white/30 text-white border-0 rounded-full p-2"
            >
              <ChevronUp className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={swipeDown}
              className="bg-white/20 hover:bg-white/30 text-white border-0 rounded-full p-2"
            >
              <ChevronDown className="w-4 h-4" />
            </Button>
          </div>

          {/* Content */}
          <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 via-black/60 to-transparent">
            <div className="space-y-4">
              {/* Category and read time */}
              <div className="flex items-center justify-between">
                <Badge variant="secondary" className="bg-white/20 text-white border-0">
                  {currentStoryData.category}
                </Badge>
                <div className="flex items-center space-x-1 text-white/80">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">{currentStoryData.readTime}</span>
                </div>
              </div>

              {/* Headline */}
              <h1 
                className="text-2xl font-bold text-white leading-tight cursor-pointer"
                onClick={() => onStoryDetail(currentStoryData)}
              >
                {currentStoryData.headline}
              </h1>

              {/* Key points */}
              <div className="space-y-2">
                {currentStoryData.keyPoints.map((point, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-teal-400 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-white/90 text-sm">{point}</p>
                  </div>
                ))}
              </div>

              {/* Why you should care */}
              <div className="bg-teal-500/90 rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-xs font-medium text-white/90">WHY YOU SHOULD CARE</span>
                </div>
                <p className="text-white font-medium text-sm">{currentStoryData.whyYouCare}</p>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-2">
                <Button
                  onClick={() => onStoryDetail(currentStoryData)}
                  className="bg-white text-gray-900 hover:bg-gray-100 rounded-xl px-6 py-2"
                >
                  Read More
                </Button>
                
                <div className="flex items-center space-x-4">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggleBookmark(currentStoryData.id)}
                    className={`text-white hover:bg-white/20 rounded-full p-2 ${
                      bookmarkedStories.has(currentStoryData.id) ? 'text-yellow-400' : ''
                    }`}
                  >
                    <Bookmark className="w-5 h-5" fill={bookmarkedStories.has(currentStoryData.id) ? 'currentColor' : 'none'} />
                  </Button>
                  
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-white hover:bg-white/20 rounded-full p-2"
                  >
                    <Share className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Swipe indicators */}
      <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
        <div className="flex flex-col space-y-2">
          {stories.map((_, index) => (
            <div
              key={index}
              className={`w-1 h-8 rounded-full transition-colors duration-300 ${
                index === currentStory ? 'bg-white' : 'bg-white/30'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}