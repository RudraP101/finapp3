import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Activity, 
  AlertTriangle,
  MapPin,
  Home,
  Car,
  Briefcase,
  GraduationCap,
  RefreshCw,
  Flame
} from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

export function LiveDashboard() {
  const [isLive, setIsLive] = useState(true);
  const [userLocation] = useState('San Francisco, CA');
  const [impactScore] = useState(75);

  // Simulate live updates
  useEffect(() => {
    const interval = setInterval(() => {
      setIsLive(prev => !prev);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const liveNewsWithImpact = [
    {
      id: 1,
      headline: 'Fed Signals Aggressive Rate Hikes',
      summary: 'Federal Reserve indicates faster interest rate increases to combat persistent inflation',
      time: '12 min ago',
      severity: 'high',
      personalImpacts: [
        {
          category: 'Housing',
          icon: <Home className="w-4 h-4" />,
          impact: 'Rent likely to increase 3-5%',
          severity: 'high',
          color: 'bg-red-100 text-red-800 border-red-200'
        },
        {
          category: 'Student Loans',
          icon: <GraduationCap className="w-4 h-4" />,
          impact: 'Interest rates up 0.5%',
          severity: 'medium',
          color: 'bg-yellow-100 text-yellow-800 border-yellow-200'
        }
      ]
    },
    {
      id: 2,
      headline: 'Tech Earnings Disappoint Across Sector',
      summary: 'Major technology companies report lower-than-expected quarterly earnings',
      time: '34 min ago',
      severity: 'medium',
      personalImpacts: [
        {
          category: 'Jobs',
          icon: <Briefcase className="w-4 h-4" />,
          impact: 'Tech hiring slowdown expected',
          severity: 'medium',
          color: 'bg-yellow-100 text-yellow-800 border-yellow-200'
        }
      ]
    },
    {
      id: 3,
      headline: 'Oil Prices Surge 8% on Supply Concerns',
      summary: 'Crude oil jumps amid geopolitical tensions and production cut announcements',
      time: '1h ago',
      severity: 'medium',
      personalImpacts: [
        {
          category: 'Gas Prices',
          icon: <Car className="w-4 h-4" />,
          impact: 'Expect +$0.25/gallon this week',
          severity: 'medium',
          color: 'bg-yellow-100 text-yellow-800 border-yellow-200'
        }
      ]
    },
    {
      id: 4,
      headline: 'Housing Market Shows Signs of Cooling',
      summary: 'Home sales decline for third consecutive month as mortgage rates climb',
      time: '2h ago',
      severity: 'low',
      personalImpacts: [
        {
          category: 'Housing',
          icon: <Home className="w-4 h-4" />,
          impact: 'Better buying opportunities ahead',
          severity: 'low',
          color: 'bg-green-100 text-green-800 border-green-200'
        }
      ]
    }
  ];

  const getScoreColor = () => {
    if (impactScore >= 80) return 'from-green-400 to-emerald-500';
    if (impactScore >= 60) return 'from-yellow-400 to-orange-500';
    return 'from-red-400 to-pink-500';
  };

  const getScoreMessage = () => {
    if (impactScore >= 80) return 'Great financial awareness! 🎉';
    if (impactScore >= 60) return 'Keep building your knowledge 📈';
    return 'Stay informed to improve 📚';
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 pt-12 pb-4">
        <div className="px-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isLive ? 'bg-red-500' : 'bg-gray-400'} animate-pulse`}></div>
              <h1 className="text-xl font-bold text-gray-900">Live Dashboard</h1>
            </div>
            <RefreshCw className="w-5 h-5 text-gray-400" />
          </div>
          <p className="text-sm text-gray-600">Real-time market impact on your life</p>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Impact Score Card */}
        <Card className={`bg-gradient-to-r ${getScoreColor()} text-white border-0 shadow-lg overflow-hidden`}>
          <div className="p-6 relative">
            <div className="absolute top-4 right-4">
              <Flame className="w-8 h-8 text-white/30" />
            </div>
            <div className="text-center">
              <h3 className="font-medium mb-2 text-white/90">Your Impact Score</h3>
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 backdrop-blur-sm">
                <span className="text-3xl font-bold">{impactScore}</span>
              </div>
              <p className="text-sm text-white/90 mb-4">{getScoreMessage()}</p>
              
              {/* Progress Bar */}
              <div className="bg-white/20 rounded-full h-2 mb-2">
                <div 
                  className="bg-white rounded-full h-2 transition-all duration-500"
                  style={{ width: `${impactScore}%` }}
                ></div>
              </div>
              <div className="flex items-center justify-between text-xs text-white/75">
                <span>Beginner</span>
                <span>Expert</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Live News with Personal Impact */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Live News & Your Impact</h3>
            <div className="flex items-center space-x-1 text-gray-500">
              <MapPin className="w-4 h-4" />
              <span className="text-sm">{userLocation}</span>
            </div>
          </div>

          {liveNewsWithImpact.map((news) => (
            <Card key={news.id} className="bg-white border-0 shadow-sm">
              <div className="p-4">
                {/* News Header */}
                <div className="border-l-4 border-red-500 pl-4 mb-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                    <Badge variant="secondary" className="bg-red-100 text-red-800 text-xs">
                      Breaking
                    </Badge>
                    <span className="text-xs text-gray-500">{news.time}</span>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">{news.headline}</h4>
                  <p className="text-sm text-gray-600">{news.summary}</p>
                </div>

                {/* Personal Impact Section */}
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <Activity className="w-4 h-4 text-teal-600" />
                    <span className="text-sm font-medium text-gray-900">How this affects you:</span>
                  </div>
                  
                  <div className="space-y-2">
                    {news.personalImpacts.map((impact, index) => (
                      <div key={index} className={`flex items-center justify-between p-3 rounded-lg border-2 ${impact.color}`}>
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                            {impact.icon}
                          </div>
                          <div>
                            <div className="font-medium text-gray-900 text-sm">{impact.category}</div>
                            <div className="text-sm text-gray-700">{impact.impact}</div>
                          </div>
                        </div>
                        <Badge variant="outline" className={`text-xs ${impact.color}`}>
                          {impact.severity}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}