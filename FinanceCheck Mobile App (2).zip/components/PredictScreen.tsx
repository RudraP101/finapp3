import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Coins, 
  Target, 
  Zap, 
  BarChart3,
  ArrowUp,
  ArrowDown,
  Trophy,
  Clock,
  Star,
  Flame,
  Home,
  Briefcase,
  Factory,
  Fuel,
  Building
} from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

export function PredictScreen() {
  const [activeTab, setActiveTab] = useState('predictions');
  const [coinBalance] = useState(1250);

  // Market Status data moved from Live Dashboard
  const marketData = [
    { symbol: 'S&P 500', value: '4,127.83', change: '-2.4%', changeValue: '-98.21', trend: 'down' },
    { symbol: 'NASDAQ', value: '12,821.22', change: '-3.1%', changeValue: '-410.38', trend: 'down' },
    { symbol: 'DOW', value: '33,596.61', change: '-1.8%', changeValue: '-612.45', trend: 'down' },
    { symbol: 'BTC', value: '$42,180', change: '+5.2%', changeValue: '+$2,089', trend: 'up' }
  ];

  const marketCategories = [
    {
      id: 1,
      category: 'Tech',
      icon: <Briefcase className="w-6 h-6" />,
      color: 'bg-blue-500',
      prediction: 'Will tech stocks rise this week?',
      description: 'Fed rate decisions and AI breakthrough announcements heavily influence tech valuations',
      suggestion: 'Lower interest rates = higher tech stock prices. Watch for Fed meetings and AI company earnings.',
      currentTrend: 'down',
      confidence: 73,
      participants: 1247,
      potential: '2x coins',
      betAmount: 50
    },
    {
      id: 2,
      category: 'Real Estate',
      icon: <Home className="w-6 h-6" />,
      color: 'bg-pink-500',
      prediction: 'Will housing prices drop next month?',
      description: 'Rising mortgage rates and inflation affect home affordability and market demand',
      suggestion: 'Higher interest rates = lower home prices. Monitor mortgage rate changes and housing inventory.',
      currentTrend: 'down',
      confidence: 82,
      participants: 892,
      potential: '2x coins',
      betAmount: 75
    },
    {
      id: 3,
      category: 'Energy',
      icon: <Fuel className="w-6 h-6" />,
      color: 'bg-orange-500',
      prediction: 'Will oil prices surge above $90?',
      description: 'Geopolitical tensions and OPEC production decisions drive energy market volatility',
      suggestion: 'Supply disruptions = higher oil prices. Track geopolitical news and OPEC announcements.',
      currentTrend: 'up',
      confidence: 65,
      participants: 445,
      potential: '2x coins',
      betAmount: 100
    },
    {
      id: 4,
      category: 'Manufacturing',
      icon: <Factory className="w-6 h-6" />,
      color: 'bg-purple-500',
      prediction: 'Will manufacturing rebound this quarter?',
      description: 'Supply chain improvements and consumer demand recovery impact manufacturing growth',
      suggestion: 'Improved supply chains = manufacturing growth. Watch PMI reports and trade data.',
      currentTrend: 'up',
      confidence: 58,
      participants: 623,
      potential: '2x coins',
      betAmount: 25
    },
    {
      id: 5,
      category: 'Banking',
      icon: <Building className="w-6 h-6" />,
      color: 'bg-green-500',
      prediction: 'Will bank stocks outperform market?',
      description: 'Interest rate changes directly affect bank profitability and loan demand',
      suggestion: 'Higher rates = better bank profits. Monitor Fed decisions and loan growth data.',
      currentTrend: 'up',
      confidence: 71,
      participants: 334,
      potential: '2x coins',
      betAmount: 60
    }
  ];

  const activePredictions = [
    {
      id: 1,
      category: 'Tech',
      prediction: 'Tech stocks will rise 5%',
      betAmount: 100,
      potential: 200,
      timeLeft: '2 days',
      status: 'winning',
      progress: 75
    },
    {
      id: 2,
      category: 'Real Estate',
      prediction: 'Housing prices will drop',
      betAmount: 75,
      potential: 150,
      timeLeft: '5 days',
      status: 'active',
      progress: 45
    },
    {
      id: 3,
      category: 'Energy',
      prediction: 'Oil above $90/barrel',
      betAmount: 50,
      potential: 100,
      timeLeft: '1 week',
      status: 'losing',
      progress: 20
    }
  ];

  const recentWins = [
    { category: 'Banking', betAmount: 50, winAmount: 100, time: '2h ago' },
    { category: 'Tech', betAmount: 75, winAmount: 150, time: '1d ago' },
    { category: 'Energy', betAmount: 25, winAmount: 50, time: '2d ago' }
  ];

  const getPredictionStatusColor = (status: string) => {
    switch (status) {
      case 'winning': return 'bg-green-100 border-green-200 text-green-800';
      case 'losing': return 'bg-red-100 border-red-200 text-red-800';
      default: return 'bg-blue-100 border-blue-200 text-blue-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 pt-12 pb-4">
        <div className="px-4">
          <h1 className="text-xl font-bold text-gray-900 mb-1">Prediction Center</h1>
          <p className="text-sm text-gray-600">Predict market moves, earn coins</p>
        </div>
      </div>

      {/* Coin Balance Card */}
      <div className="p-4">
        <Card className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 shadow-lg">
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-white/80 mb-1">Your Coin Balance</h3>
                <div className="text-3xl font-bold mb-2">{coinBalance.toLocaleString()}</div>
                <div className="flex items-center space-x-4 text-sm text-white/90">
                  <div className="flex items-center space-x-1">
                    <Trophy className="w-4 h-4" />
                    <span>Level 7</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4" />
                    <span>15 wins</span>
                  </div>
                </div>
              </div>
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <Coins className="w-8 h-8 text-white" />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Market Status Section (moved from Live Dashboard) */}
      <div className="px-4 mb-4">
        <Card className="bg-white border-0 shadow-sm">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Market Status</h3>
              <Badge variant="secondary" className="bg-red-100 text-red-800">
                Markets Down
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              {marketData.map((item) => (
                <div key={item.symbol} className="bg-gray-50 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-900">{item.symbol}</span>
                    {item.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                  <div className="font-bold text-gray-900 mb-1">{item.value}</div>
                  <div className={`text-sm ${item.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {item.change} ({item.changeValue})
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Tab Navigation */}
      <div className="px-4 mb-4">
        <div className="flex space-x-1 bg-gray-100 rounded-xl p-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveTab('predictions')}
            className={`flex-1 rounded-lg text-sm font-medium ${
              activeTab === 'predictions' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-600'
            }`}
          >
            <Target className="w-4 h-4 mr-2" />
            My Predictions
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setActiveTab('opportunities')}
            className={`flex-1 rounded-lg text-sm font-medium ${
              activeTab === 'opportunities' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-600'
            }`}
          >
            <Zap className="w-4 h-4 mr-2" />
            Markets
          </Button>
        </div>
      </div>

      <div className="px-4">
        {/* My Predictions Tab */}
        {activeTab === 'predictions' && (
          <div className="space-y-4">
            {/* Recent Wins */}
            <Card className="bg-white border-0 shadow-sm">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-gray-900">Recent Wins 🎉</h3>
                  <Badge className="bg-green-500">
                    +{recentWins.reduce((sum, win) => sum + (win.winAmount - win.betAmount), 0)} coins
                  </Badge>
                </div>
                <div className="space-y-2">
                  {recentWins.map((win, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-xl">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Trophy className="w-4 h-4 text-green-600" />
                        </div>
                        <div>
                          <div className="font-medium text-gray-900 text-sm">{win.category} prediction</div>
                          <div className="text-xs text-gray-500">Bet {win.betAmount} • Won {win.winAmount}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-600">+{win.winAmount - win.betAmount}</div>
                        <div className="text-xs text-gray-500">{win.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            {/* Active Predictions */}
            <Card className="bg-white border-0 shadow-sm">
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-4">Active Predictions</h3>
                <div className="space-y-4">
                  {activePredictions.map((prediction) => (
                    <Card key={prediction.id} className={`border-2 ${getPredictionStatusColor(prediction.status)}`}>
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <div className="font-semibold text-gray-900">{prediction.category}</div>
                            <div className="text-sm text-gray-600">{prediction.prediction}</div>
                          </div>
                          <Badge variant="outline" className={getPredictionStatusColor(prediction.status)}>
                            {prediction.status}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 gap-4 mb-3">
                          <div>
                            <div className="text-xs text-gray-500">Bet Amount</div>
                            <div className="font-semibold text-gray-900">{prediction.betAmount} coins</div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-500">Potential Win</div>
                            <div className="font-semibold text-gray-900">{prediction.potential} coins</div>
                          </div>
                        </div>

                        <div className="mb-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs text-gray-500">Progress</span>
                            <span className="text-xs text-gray-600">{prediction.progress}%</span>
                          </div>
                          <Progress value={prediction.progress} className="h-2" />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3 text-gray-500" />
                            <span className="text-xs text-gray-600">{prediction.timeLeft} left</span>
                          </div>
                          <span className="text-xs font-medium text-gray-600">
                            {prediction.status === 'winning' ? '🎉 Winning!' : 
                             prediction.status === 'losing' ? '😬 Behind' : '⏳ In Progress'}
                          </span>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Market Categories Tab */}
        {activeTab === 'opportunities' && (
          <div className="space-y-4">
            <div className="space-y-4">
              {marketCategories.map((market) => (
                <Card key={market.id} className="bg-white border-0 shadow-sm">
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start space-x-3">
                        <div className={`w-12 h-12 ${market.color} rounded-xl flex items-center justify-center text-white shadow-sm`}>
                          {market.icon}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-1">{market.category}</h4>
                          <p className="text-sm font-medium text-gray-800 mb-2">{market.prediction}</p>
                          <p className="text-xs text-gray-600 mb-2">{market.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        {market.currentTrend === 'up' ? (
                          <ArrowUp className="w-4 h-4 text-green-500" />
                        ) : (
                          <ArrowDown className="w-4 h-4 text-red-500" />
                        )}
                      </div>
                    </div>

                    {/* Market suggestion */}
                    <div className="bg-blue-50 rounded-lg p-3 mb-4">
                      <div className="flex items-start space-x-2">
                        <Zap className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-blue-800">{market.suggestion}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4 text-xs text-gray-600">
                        <div className="flex items-center space-x-1">
                          <BarChart3 className="w-3 h-3" />
                          <span>{market.confidence}% confident</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Trophy className="w-3 h-3" />
                          <span>{market.participants} players</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-gray-900">Bet: {market.betAmount} coins</span>
                        <span className="text-sm text-green-600">Win: {market.potential}</span>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="border-green-200 text-green-700 hover:bg-green-50 rounded-lg mobile-touch"
                        >
                          <ArrowUp className="w-4 h-4 mr-1" />
                          Up
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="border-red-200 text-red-700 hover:bg-red-50 rounded-lg mobile-touch"
                        >
                          <ArrowDown className="w-4 h-4 mr-1" />
                          Down
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}