import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface Story {
  id: string;
  headline: string;
  category: string;
  timeAgo: string;
  readTime: string;
  source?: string;
  summary: string;
  content?: string;
  vocabTerm?: {
    word: string;
    definition: string;
    example: string;
  };
}

interface ScrollableReaderProps {
  stories: Story[];
  initialIndex?: number;
  context: 'daily' | 'topic';
  topicName?: string;
  onClose: () => void;
}

export function ScrollableReader({ 
  stories, 
  initialIndex = 0, 
  context, 
  topicName, 
  onClose 
}: ScrollableReaderProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [touchStartX, setTouchStartX] = useState(0);
  const [touchStartY, setTouchStartY] = useState(0);
  const [touchEndX, setTouchEndX] = useState(0);
  const [touchEndY, setTouchEndY] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);

  const currentStory = stories[currentIndex];

  // Generate story content with proper narrative structure
  const generateStoryContent = (story: Story): string => {
    const baseContent = story.content || story.summary;
    
    // Create a cohesive narrative from the summary and additional context
    const narrativeParts = [
      baseContent,
      generateCategorySpecificNarrative(story.category),
      generateMarketContextNarrative(story.category)
    ].filter(Boolean);

    return narrativeParts.join(' ');
  };

  const generateCategorySpecificNarrative = (category: string): string => {
    const narrativeMap: { [key: string]: string } = {
      'Economy': 'This development reflects broader economic trends that affect both institutional investors and individual consumers. Federal Reserve policies continue to shape market expectations, with particular attention to inflation indicators and employment data.',
      'Technology': 'The technology sector remains highly sensitive to interest rate changes and regulatory developments. Market participants are closely monitoring AI advancement, semiconductor supply chains, and changing consumer technology adoption patterns.',
      'Housing': 'Housing market dynamics have far-reaching effects on household wealth and consumer spending behavior. Mortgage rate fluctuations directly impact affordability, while inventory levels influence price trends across different regional markets.',
      'Student Finance': 'Student loan policy changes affect millions of borrowers and have broader economic implications for consumer spending and debt levels. These developments influence young adults\' financial decisions and purchasing power.',
      'Jobs': 'Employment trends provide key insights into economic health and future consumer confidence. Wage growth patterns indicate both inflationary pressures and workers\' financial wellbeing across different sectors.',
      'Investing': 'Investment market developments reflect changing investor sentiment about economic conditions and policy directions. Understanding these trends helps individuals make informed decisions about their financial portfolios.'
    };
    
    return narrativeMap[category] || 'This development has significant implications for market participants and individual financial planning decisions.';
  };

  const generateMarketContextNarrative = (category: string): string => {
    return 'Financial experts recommend staying informed about these developments while maintaining a long-term perspective on personal financial goals. Understanding market dynamics helps individuals make better decisions about spending, saving, and investing.';
  };

  // Enhanced touch handling with better gesture recognition
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.targetTouches[0].clientX);
    setTouchStartY(e.targetTouches[0].clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEndX(e.targetTouches[0].clientX);
    setTouchEndY(e.targetTouches[0].clientY);
  };

  const handleTouchEnd = () => {
    if (!touchStartX || !touchEndX || !touchStartY || !touchEndY) return;
    
    const distanceX = touchStartX - touchEndX;
    const distanceY = touchStartY - touchEndY;
    const isHorizontalSwipe = Math.abs(distanceX) > Math.abs(distanceY) && Math.abs(distanceX) > 50;
    const isVerticalSwipe = Math.abs(distanceY) > Math.abs(distanceX) && Math.abs(distanceY) > 100;

    // Horizontal swipes for next/previous story
    if (isHorizontalSwipe) {
      const isLeftSwipe = distanceX > 0;
      const isRightSwipe = distanceX < 0;

      if (isLeftSwipe && currentIndex < stories.length - 1) {
        handleNext();
      }
      if (isRightSwipe && currentIndex > 0) {
        handlePrevious();
      }
    }

    // Vertical swipe down to close
    if (isVerticalSwipe && distanceY < 0) {
      onClose();
    }

    // Reset touch positions
    setTouchStartX(0);
    setTouchStartY(0);
    setTouchEndX(0);
    setTouchEndY(0);
  };

  // Handle tap on sides to navigate (with dead zone in center)
  const handleSideClick = (e: React.MouseEvent, side: 'left' | 'right') => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const centerStart = rect.width * 0.3;
    const centerEnd = rect.width * 0.7;
    
    // Ignore clicks in center area
    if (clickX >= centerStart && clickX <= centerEnd) {
      return;
    }
    
    if (side === 'left' && currentIndex > 0) {
      handlePrevious();
    } else if (side === 'right' && currentIndex < stories.length - 1) {
      handleNext();
    }
  };

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
      // Scroll to top of new story
      if (contentRef.current) {
        contentRef.current.scrollTop = 0;
      }
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      // Scroll to top of new story
      if (contentRef.current) {
        contentRef.current.scrollTop = 0;
      }
    }
  };

  // Keyboard navigation support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
          e.preventDefault();
          if (currentIndex > 0) handlePrevious();
          break;
        case 'ArrowRight':
          e.preventDefault();
          if (currentIndex < stories.length - 1) handleNext();
          break;
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, stories.length, onClose]);

  return (
    <div className="min-h-screen bg-white relative overflow-hidden">
      {/* Compact Header with reduced padding */}
      <div className="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-gray-100 z-20">
        <div className="flex items-center justify-between px-4 pt-4 pb-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="rounded-full p-2 hover:bg-gray-100 transition-colors"
            aria-label="Close reader"
          >
            <X className="w-5 h-5 text-gray-600" />
          </Button>
          
          <div className="text-center">
            <div className="text-sm font-medium text-gray-900">
              {context === 'topic' ? topicName : 'Daily Stories'}
            </div>
            <div className="text-xs text-gray-500">
              {currentIndex + 1} of {stories.length}
            </div>
          </div>
          
          <div className="w-9" aria-hidden="true" />
        </div>

        {/* Progress indicators */}
        <div className="flex space-x-1 px-4 pb-3" role="progressbar" aria-valuenow={currentIndex + 1} aria-valuemax={stories.length}>
          {stories.map((_, index) => (
            <div
              key={index}
              className={`flex-1 h-0.5 rounded-full transition-colors duration-300 ${
                index === currentIndex ? 'bg-teal-500' : 
                index < currentIndex ? 'bg-teal-200' : 'bg-gray-200'
              }`}
              aria-hidden="true"
            />
          ))}
        </div>
      </div>

      {/* Story Content with enhanced touch handling */}
      <div
        ref={contentRef}
        className="relative px-4 pb-8 overflow-y-auto"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{ height: 'calc(100vh - 120px)' }} // Account for header height
      >
        {/* Invisible tap zones for navigation */}
        <div className="absolute inset-0 flex pointer-events-auto">
          <div 
            className="flex-1 cursor-pointer"
            onClick={(e) => handleSideClick(e, 'left')}
            aria-label="Previous story"
          />
          <div 
            className="flex-1 cursor-pointer"
            onClick={(e) => handleSideClick(e, 'right')}
            aria-label="Next story"
          />
        </div>

        {/* Story Header with improved spacing */}
        <div className="relative z-10 mb-6 pt-2">
          <div className="flex items-center space-x-3 mb-4">
            <Badge 
              variant="secondary" 
              className="bg-gray-100 text-gray-800 rounded-full px-3 py-1 text-sm"
            >
              {currentStory.category}
            </Badge>
            
            <div className="flex items-center space-x-3 text-sm text-gray-500">
              <span>{currentStory.timeAgo}</span>
              <span aria-hidden="true">•</span>
              <span>{currentStory.readTime}</span>
              {currentStory.source && (
                <>
                  <span aria-hidden="true">•</span>
                  <span>{currentStory.source}</span>
                </>
              )}
            </div>
          </div>

          <h1 className="text-2xl font-bold text-gray-900 mb-4 leading-tight">
            {currentStory.headline}
          </h1>
        </div>

        {/* Story Body with improved readability */}
        <div className="relative z-10 space-y-6 max-w-none">
          <div className="prose prose-gray max-w-none">
            {generateStoryContent(currentStory).split('. ').map((sentence, index, array) => {
              // Group sentences into paragraphs (every 3-4 sentences)
              const shouldStartNewParagraph = index === 0 || index % 4 === 0;
              const isLastSentence = index === array.length - 1;
              const sentence_text = sentence + (isLastSentence ? '' : '. ');
              
              if (shouldStartNewParagraph) {
                const paragraphSentences = array.slice(index, Math.min(index + 4, array.length));
                const paragraphText = paragraphSentences.join('. ') + (paragraphSentences.length < 4 ? '' : '.');
                
                return (
                  <p key={index} className="text-gray-700 leading-relaxed mb-4 text-base">
                    {paragraphText}
                  </p>
                );
              }
              
              return null;
            }).filter(Boolean)}
          </div>

          {/* Learn Box with enhanced accessibility */}
          {currentStory.vocabTerm && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mt-8" role="complementary" aria-labelledby="vocab-heading">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0" aria-hidden="true">
                  <span className="text-sm">💡</span>
                </div>
                <div className="flex-1">
                  <h3 id="vocab-heading" className="font-semibold text-blue-900 mb-2">Learn</h3>
                  <div className="text-sm">
                    <dt className="font-medium text-blue-900 mb-1">{currentStory.vocabTerm.word}:</dt>
                    <dd className="text-blue-800 mb-3">{currentStory.vocabTerm.definition}</dd>
                    <div className="text-blue-700 italic">
                      <span className="sr-only">Example: </span>
                      {currentStory.vocabTerm.example}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation arrows for desktop/larger screens */}
        <div className="hidden md:flex absolute inset-y-0 left-0 right-0 items-center justify-between px-4 pointer-events-none">
          {currentIndex > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handlePrevious}
              className="rounded-full bg-white shadow-lg hover:bg-gray-50 pointer-events-auto transition-all duration-200"
              aria-label="Previous story"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
          )}
          <div aria-hidden="true" />
          {currentIndex < stories.length - 1 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleNext}
              className="rounded-full bg-white shadow-lg hover:bg-gray-50 pointer-events-auto transition-all duration-200"
              aria-label="Next story"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          )}
        </div>
      </div>

      {/* Screen reader instructions */}
      <div className="sr-only" aria-live="polite" aria-atomic="true">
        Story {currentIndex + 1} of {stories.length}. 
        Use arrow keys or swipe to navigate between stories. 
        Press Escape or swipe down to close.
      </div>
    </div>
  );
}