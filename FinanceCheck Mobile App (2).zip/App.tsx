import React, { useState } from 'react';
import { OnboardingScreens } from './components/OnboardingScreens';
import { HomeScreen } from './components/HomeScreen';
import { ScrollableReader } from './components/ScrollableReader';
import { LiveDashboard } from './components/LiveDashboard';
import { SocialScreen } from './components/SocialScreen';
import { PredictScreen } from './components/PredictScreen';
import { Navigation } from './components/Navigation';

interface Story {
  id: string;
  headline: string;
  category: string;
  timeAgo: string;
  readTime: string;
  source?: string;
  summary: string;
  content?: string;
  vocabTerm?: {
    word: string;
    definition: string;
    example: string;
  };
}

interface ReaderContext {
  stories: Story[];
  initialIndex: number;
  context: 'daily' | 'topic';
  topicName?: string;
}

export default function App() {
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [readerContext, setReaderContext] = useState<ReaderContext | null>(null);

  // Sample daily stories data
  const dailyStories: Story[] = [
    {
      id: '1',
      headline: 'Fed Cuts Interest Rates by 0.25%',
      category: 'Economy',
      timeAgo: '2h ago',
      readTime: '3 min',
      source: 'Reuters',
      summary: 'Federal Reserve announces another rate cut to support economic growth amid inflation concerns.',
      vocabTerm: {
        word: 'Federal Funds Rate',
        definition: 'The interest rate at which banks lend money to each other overnight.',
        example: 'When the Fed cuts the federal funds rate, borrowing becomes cheaper for businesses and consumers.'
      }
    },
    {
      id: '2',
      headline: 'Tech Giants Report Mixed Earnings',
      category: 'Technology',
      timeAgo: '4h ago',
      readTime: '4 min',
      source: 'CNBC',
      summary: 'Apple beats expectations while Meta disappoints, showing divergent trends in big tech performance.',
      vocabTerm: {
        word: 'Earnings Per Share (EPS)',
        definition: 'A company\'s profit divided by the number of outstanding shares.',
        example: 'Apple\'s EPS of $1.64 exceeded analyst expectations of $1.60 per share.'
      }
    },
    {
      id: '3',
      headline: 'Student Loan Forgiveness Expands',
      category: 'Student Finance',
      timeAgo: '6h ago',
      readTime: '2 min',
      source: 'NPR',
      summary: 'Biden administration approves $7.4 billion in loan forgiveness for public service workers.',
      vocabTerm: {
        word: 'Public Service Loan Forgiveness',
        definition: 'A program that forgives student loans for qualifying public service employees after 10 years.',
        example: 'Teachers and nurses can qualify for PSLF after making 120 qualifying payments while working full-time in public service.'
      }
    },
    {
      id: '4',
      headline: 'Housing Market Shows Signs of Cooling',
      category: 'Housing',
      timeAgo: '8h ago',
      readTime: '3 min',
      source: 'MarketWatch',
      summary: 'Home sales decline for third consecutive month as mortgage rates reach 18-month highs.',
      vocabTerm: {
        word: 'Mortgage Rate',
        definition: 'The interest rate charged on a home loan, affecting monthly payment amounts.',
        example: 'A 1% increase in mortgage rates can reduce buying power by approximately 10%.'
      }
    },
    {
      id: '5',
      headline: 'Crypto Market Rallies 15%',
      category: 'Investing',
      timeAgo: '10h ago',
      readTime: '2 min',
      source: 'CoinDesk',
      summary: 'Bitcoin hits $45,000 as institutional investors buy the dip following regulatory clarity.',
      vocabTerm: {
        word: 'ETF (Exchange-Traded Fund)',
        definition: 'A fund that trades on stock exchanges like individual stocks but holds a collection of assets.',
        example: 'The Bitcoin ETF allows investors to gain crypto exposure without directly owning cryptocurrency.'
      }
    },
    {
      id: '6',
      headline: 'Job Market Remains Strong',
      category: 'Jobs',
      timeAgo: '12h ago',
      readTime: '3 min',
      source: 'Bureau of Labor Statistics',
      summary: 'September jobs report shows 200,000 new positions added, unemployment stays at historic lows.',
      vocabTerm: {
        word: 'Unemployment Rate',
        definition: 'The percentage of the labor force that is jobless and actively seeking employment.',
        example: 'An unemployment rate of 3.8% means that out of 100 people in the labor force, about 4 are unemployed.'
      }
    }
  ];

  // Handle onboarding completion
  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
  };

  // Handle daily stories
  const handleShowDailyStories = () => {
    setReaderContext({
      stories: dailyStories,
      initialIndex: 0,
      context: 'daily'
    });
  };

  // Handle topic story selection
  const handleShowTopicStories = (topicName: string, stories: Story[], initialIndex: number = 0) => {
    setReaderContext({
      stories,
      initialIndex,
      context: 'topic',
      topicName
    });
  };

  // Handle story selection from home (for individual stories)
  const handleStoryDetail = (story: Story, stories?: Story[]) => {
    // If stories array is provided, find the index of the selected story
    if (stories) {
      const index = stories.findIndex(s => s.id === story.id);
      setReaderContext({
        stories,
        initialIndex: Math.max(0, index),
        context: 'topic',
        topicName: story.category
      });
    } else {
      // Single story view (fallback)
      setReaderContext({
        stories: [story],
        initialIndex: 0,
        context: 'topic',
        topicName: story.category
      });
    }
  };

  // Handle back from reader
  const handleBackFromReader = () => {
    setReaderContext(null);
  };

  // Show onboarding first
  if (showOnboarding) {
    return <OnboardingScreens onComplete={handleOnboardingComplete} />;
  }

  // Show reader if context is set
  if (readerContext) {
    return (
      <ScrollableReader
        stories={readerContext.stories}
        initialIndex={readerContext.initialIndex}
        context={readerContext.context}
        topicName={readerContext.topicName}
        onClose={handleBackFromReader}
      />
    );
  }

  // Main app content with navigation
  const renderActiveScreen = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomeScreen 
            onDailyStories={handleShowDailyStories}
            onStoryDetail={handleStoryDetail}
            onShowTopicStories={handleShowTopicStories}
          />
        );
      case 'live':
        return <LiveDashboard />;
      case 'social':
        return <SocialScreen />;
      case 'predict':
        return <PredictScreen />;
      default:
        return (
          <HomeScreen 
            onDailyStories={handleShowDailyStories}
            onStoryDetail={handleStoryDetail}
            onShowTopicStories={handleShowTopicStories}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Main content area */}
      <div>
        {renderActiveScreen()}
      </div>

      {/* Bottom navigation */}
      <Navigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
      />
    </div>
  );
}